import 'package:flutter/material.dart';

void main() => runApp(const GoCruzApp());

const navy = Color(0xFF102B52);
const pale = Color(0xFFF4F7FB);

class GoCruzApp extends StatelessWidget {
  const GoCruzApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'GO CRUZ',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: navy), scaffoldBackgroundColor: pale, useMaterial3: true),
        home: const HomePage(),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int selected = 0;
  final items = const [
    _Service('Ride', Icons.directions_car_filled_rounded, 'Book a city ride'),
    _Service('Bike', Icons.two_wheeler_rounded, 'Quick two-wheeler trips'),
    _Service('Rentals', Icons.car_rental_rounded, 'Travel on your schedule'),
    _Service('Travel', Icons.explore_rounded, 'Plan your next journey'),
  ];

  @override
  Widget build(BuildContext context) {
    final service = items[selected];
    return Scaffold(
      appBar: AppBar(backgroundColor: navy, foregroundColor: Colors.white, title: const Text('GO CRUZ', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.4)), actions: [IconButton(onPressed: () => _notice('Profile coming soon'), icon: const Icon(Icons.account_circle_outlined))]),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
        Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)), child: Column(children: [Image.asset('assets/go_cruz_logo.png', height: 150, fit: BoxFit.contain), const Text('Your Journey, Your Way.', style: TextStyle(color: navy, fontWeight: FontWeight.w600, letterSpacing: .4)), const SizedBox(height: 8)])),
        const SizedBox(height: 24),
        const Text('Where would you like to go?', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800, color: navy)),
        const SizedBox(height: 14),
        GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: items.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.22), itemBuilder: (context, i) { final s = items[i]; final active = selected == i; return InkWell(borderRadius: BorderRadius.circular(18), onTap: () => setState(() => selected = i), child: Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: active ? navy : Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: active ? navy : const Color(0xFFDCE4EF))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Icon(s.icon, size: 32, color: active ? Colors.white : navy), const SizedBox(height: 10), Text(s.name, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17, color: active ? Colors.white : navy)), Text(s.caption, maxLines: 2, style: TextStyle(fontSize: 11, color: active ? Colors.white70 : Colors.blueGrey))]))); }),
        const SizedBox(height: 22),
        Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${service.name} with GO CRUZ', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: navy)), const SizedBox(height: 6), Text(service.caption, style: const TextStyle(color: Colors.blueGrey)), const SizedBox(height: 16), TextField(decoration: InputDecoration(prefixIcon: const Icon(Icons.my_location, color: navy), hintText: 'Pickup location', filled: true, fillColor: pale, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none))), const SizedBox(height: 10), TextField(decoration: InputDecoration(prefixIcon: const Icon(Icons.location_on_outlined, color: navy), hintText: 'Where to?', filled: true, fillColor: pale, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none))), const SizedBox(height: 16), SizedBox(width: double.infinity, child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: navy, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 15)), onPressed: () => _notice('Booking preview only. Live bookings will be added in a future version.'), icon: const Icon(Icons.arrow_forward_rounded), label: const Text('Continue')))])),
        const SizedBox(height: 18), const Center(child: Text('Prototype • Live booking is not enabled yet', style: TextStyle(fontSize: 12, color: Colors.blueGrey))),
      ])),
      bottomNavigationBar: NavigationBar(selectedIndex: 0, onDestinationSelected: (i) { if (i != 0) _notice(['Home', 'My Trips', 'Support', 'Account'][i] + ' coming soon'); }, destinations: const [NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'), NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'My Trips'), NavigationDestination(icon: Icon(Icons.support_agent_outlined), label: 'Support'), NavigationDestination(icon: Icon(Icons.person_outline), label: 'Account')]),
    );
  }
  void _notice(String message) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}

class _Service {
  final String name; final IconData icon; final String caption;
  const _Service(this.name, this.icon, this.caption);
}
