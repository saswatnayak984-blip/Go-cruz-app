# GO CRUZ Flutter Prototype

A starter UI prototype for GO CRUZ / Cruise Rides using navy blue and white branding. It is not connected to live drivers, maps, payments, or booking services yet.

## Run locally
1. Install Flutter SDK and Android tooling on a computer.
2. From this folder run `flutter pub get`.
3. Run `flutter run` with an Android device/emulator connected.
4. Build an installable APK with `flutter build apk --release`.

## Android-phone-only workflow
1. Create a new repository on https://github.com/new (for example `go-cruz-app`).
2. Upload the project files into the repository using GitHub's web interface. Keep `pubspec.yaml`, `lib/main.dart`, and `assets/go_cruz_logo.png` at the paths shown in this ZIP.
3. A GitHub repository alone does not build an APK. To compile from a phone, connect the repository to a Flutter-compatible cloud build service, or use a cloud development environment that supports Flutter and Android SDK. Build availability/quotas depend on the provider.

This is a UI prototype only. Real ride booking needs a backend, maps/location, driver workflows, security, and payment integration before production or Play Store release.
